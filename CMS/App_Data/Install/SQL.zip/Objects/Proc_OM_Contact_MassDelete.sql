SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_Contact_MassDelete]
@where nvarchar(max),
	@batchLimit int
AS
BEGIN
SET NOCOUNT ON;
	-- Variables
	DECLARE @DeletedContacts TABLE (
		ContactID int NOT NULL,
		ContactGUID uniqueidentifier NOT NULL
	);	
    DECLARE @Result TABLE (
        ContactID int NOT NULL,
		ContactGUID uniqueidentifier NOT NULL
    );
	DECLARE @sqlQuery NVARCHAR(MAX);
	DECLARE @top NVARCHAR(20);
	
	-- Limit processed batch
	IF ((@batchLimit IS NOT NULL) OR (@batchLimit > 0))
		SET @top = 'TOP ' + CAST(@batchLimit AS NVARCHAR(10));
	ELSE 
		SET @top = 'TOP 1000';
	
	SET @sqlQuery = 'SELECT ' + @top + ' ContactID, ContactGUID FROM OM_Contact WHERE ' + @where;
	INSERT INTO @DeletedContacts EXEC(@sqlQuery);
	
	-- Process first batch of records
	WHILE ((SELECT Count(*) FROM @DeletedContacts) > 0)
	BEGIN			
		-- Loop through records
		IF ((SELECT Count(*) FROM @DeletedContacts) > 0)
		BEGIN	
			-- Clear account fields
			UPDATE o SET o.AccountPrimaryContactID = NULL FROM OM_Account o INNER JOIN @DeletedContacts d ON o.AccountPrimaryContactID = d.ContactID;
			UPDATE o SET o.AccountSecondaryContactID = NULL FROM OM_Account o INNER JOIN @DeletedContacts d ON o.AccountSecondaryContactID = d.ContactID;
			-- Remove all relations
			DELETE o FROM OM_AccountContact o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID;
			DELETE o FROM OM_ContactGroupMember o LEFT JOIN @DeletedContacts d ON o.ContactGroupMemberRelatedID = d.ContactID WHERE o.ContactGroupMemberType=0 AND d.ContactID IS NOT NULL;
			DELETE o FROM OM_Membership o LEFT JOIN @DeletedContacts do ON o.ContactID = do.ContactID WHERE do.ContactID IS NOT NULL;
			DELETE o FROM OM_ScoreContactRule o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID;
			-- Delete relations from depending activity
			DELETE o FROM OM_Activity o LEFT JOIN @DeletedContacts do ON o.ActivityContactID = do.ContactID WHERE do.ContactID IS NOT NULL;			
			-- Remove all visitor to contact relations
			DELETE o FROM OM_VisitorToContact o INNER JOIN @DeletedContacts d ON o.VisitorToContactContactID = d.ContactID;
			
			-- Delete contact approved consents
			DELETE o FROM CMS_ConsentAgreement o INNER JOIN @DeletedContacts d ON o.ConsentAgreementContactID = d.ContactID;

			-- Delete contacts
			DELETE o FROM OM_Contact o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID ;
            
			-- Store deleted IDs before clearing batch handler
            INSERT INTO @Result SELECT DISTINCT * FROM @DeletedContacts
			DELETE FROM @DeletedContacts
		END
		
		-- Get next batch
		IF (@batchLimit IS  NULL)
			INSERT INTO @DeletedContacts EXEC(@sqlQuery);
	END
    -- Return all deleted contacts IDs
    SELECT * FROM @Result;
END





GO
