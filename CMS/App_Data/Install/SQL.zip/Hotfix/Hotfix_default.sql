-- HF12-8 - [SECURITY] Missing access controls in Forums and Group Forums UI
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')

IF @HOTFIXVERSION < 2
BEGIN
	UPDATE [CMS_UIElement] SET [ElementAccessCondition] = N'{% CurrentUser.IsAuthorizedPerGroup(EditedObjectParent.GroupGroupID, "Read", CurrentSiteID) @%}'
	WHERE [ElementGUID] = 'DE463408-6153-447B-B7AC-785479D98087'
END
GO

-- HF12-32 Shorten 'Execute Azure search tasks' scheduled task interval
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 5
BEGIN

DECLARE @taskResourceID int;
SET @taskResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceGUID] = '6b0a5d42-3671-4eec-8d05-0d3d249ef207')
IF @taskResourceID IS NOT NULL BEGIN

DECLARE @interval nvarchar(1000);
SET @interval = (SELECT TOP 1 [TaskInterval] FROM [CMS_ScheduledTask] WHERE [TaskGUID] = '5efb0637-041c-4260-b570-05eff059ee91')
  IF (@interval LIKE N'hour;%' AND @interval LIKE N'%;4;%')
  BEGIN
   -- Shorten the interval from 4 hours to 1 minute, if not already customized
	SET @interval = REPLACE(@interval, N'hour;', N'minute;')
	SET @interval = REPLACE(@interval, N';4;', N';1;')

	UPDATE [CMS_ScheduledTask] SET [TaskInterval] = @interval WHERE [TaskGUID] = '5efb0637-041c-4260-b570-05eff059ee91'
  END

END

END

GO

-- HF12-41 - "Listing with general selector" page template change
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 7
BEGIN

DECLARE @pageTemplateCategoryID int;
SET @pageTemplateCategoryID = (SELECT TOP 1 [CategoryID] FROM [CMS_PageTemplateCategory] WHERE [CategoryGUID] = '0cd9d6f5-4393-4f6d-9273-c7e667809496')
IF @pageTemplateCategoryID IS NOT NULL BEGIN

UPDATE [CMS_PageTemplate] SET 
        [PageTemplateProperties] = '<form version="2"><category name="Sselector"><properties><caption>Selector</caption><visible>True</visible></properties></category><field allowempty="true" column="SelectionMode" columnsize="10" columntype="text" displayinsimplemode="true" guid="9bebe338-6d8f-4e05-84ff-26f576d10d68" publicfield="false" visible="true"><properties><defaultvalue>1</defaultvalue><fieldcaption>Selection mode</fieldcaption><fielddescription>{$documentation.property.selectionmode$}</fielddescription></properties><settings><controlname>dropdownlistcontrol</controlname><EditText>False</EditText><Options>0;Single text box
1;Single drop down list
2;Multiple
3;Multiple text box
4;Single button
5;Multiple button</Options><SortItems>False</SortItems></settings></field><field allowempty="true" column="SelectorObjectType" columnsize="100" columntype="text" displayinsimplemode="true" guid="c0e14831-33fd-48cc-b2ab-35badbdda37f" publicfield="false" visible="true"><properties><fieldcaption>Selector object type</fieldcaption><fielddescription>{$documentation.property.objecttype$}</fielddescription></properties><settings><AddGlobalObjectNamePrefix>False</AddGlobalObjectNamePrefix><AddGlobalObjectSuffix>False</AddGlobalObjectSuffix><AllowAll>False</AllowAll><AllowDefault>False</AllowDefault><AllowEditTextBox>False</AllowEditTextBox><AllowEmpty>True</AllowEmpty><controlname>objectselector</controlname><DialogWindowHeight>590</DialogWindowHeight><DialogWindowName>SelectionDialog</DialogWindowName><DialogWindowWidth>668</DialogWindowWidth><GlobalObjectSuffix>(global)</GlobalObjectSuffix><ItemsPerPage>25</ItemsPerPage><LocalizeItems>True</LocalizeItems><MaxDisplayedItems>25</MaxDisplayedItems><MaxDisplayedTotalItems>50</MaxDisplayedTotalItems><ObjectType>cms.class</ObjectType><RemoveMultipleCommas>False</RemoveMultipleCommas><ResourcePrefix>objectselect</ResourcePrefix><ReturnColumnName>ClassName</ReturnColumnName><SelectionMode>1</SelectionMode><ValuesSeparator>;</ValuesSeparator></settings></field><field allowempty="true" column="ReturnColumnName" columnsize="100" columntype="text" displayinsimplemode="true" guid="5ebf33d9-7af2-462d-9ae3-4ae724ed6566" publicfield="false" visible="true"><properties><fieldcaption>Return column name</fieldcaption><fielddescription>{$documentation.property.returncolumnname$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="DisplayNameFormat" columnsize="1000" columntype="text" displayinsimplemode="true" guid="6d5f6c56-25c4-414e-b924-9a74a989a772" publicfield="false" visible="true"><properties><fieldcaption>Display name format</fieldcaption><fielddescription>Specifies the name of the column that will be stored by the selector. If empty, the ID column is used. To ensure correct functionality, the column must be a unique identifier for the given object type.</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="SelectedValue" columnsize="1000" columntype="text" displayinsimplemode="true" guid="910cf47f-2311-469e-bf90-ebb041e50c6f" publicfield="false" visible="true"><properties><fieldcaption>Selected value</fieldcaption><fielddescription>{$documentation.property.selectedvalue$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="SelectorLabel" columnsize="300" columntype="text" displayinsimplemode="true" guid="f6e588e9-cbdb-411a-a1de-8fb487404b34" publicfield="false" visible="true"><properties><fieldcaption>Selector label</fieldcaption><fielddescription>{$documentation.property.selectorlabel$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="ContextName" columnsize="100" columntype="text" displayinsimplemode="true" guid="d1d75bf7-632d-441d-8bb8-580e5c43d97e" publicfield="false" visible="true"><properties><defaultvalue>SelectorValue</defaultvalue><fieldcaption>Context name</fieldcaption><fielddescription>{$documentation.property.contextname$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="PostbackOnChange" columntype="boolean" displayinsimplemode="true" guid="e8b3e35a-c280-4f00-917a-2dddd1a2cfb6" publicfield="false" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Postback on change</fieldcaption><fielddescription>{$documentation.property.postbackonchange$}</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="SelectorWhereCondition" columnsize="400" columntype="text" displayinsimplemode="true" guid="81e29d5c-6489-472f-a909-5a0e3adeccbf" publicfield="false" resolvedefaultvalue="False" visible="true"><properties><fieldcaption>Selector where condtion</fieldcaption><fielddescription>{$documentation.property.uniselectorwherecondition$}</fielddescription></properties><settings><AutoSize>False</AutoSize><controlname>macroeditor</controlname><EnablePositionMember>False</EnablePositionMember><EnableSections>False</EnableSections><EnableViewState>False</EnableViewState><Height>100</Height><Language>0</Language><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><ShowMacroSelector>False</ShowMacroSelector><SingleLineMode>False</SingleLineMode><SingleMacroMode>False</SingleMacroMode><SupportPasteImages>False</SupportPasteImages><Width>100%</Width></settings></field><field allowempty="true" column="SelectorOrderBy" columnsize="500" columntype="text" guid="c48adebd-8027-4489-8839-6dec9b6e23f1" publicfield="false" resolvedefaultvalue="False" visible="true"><properties><fieldcaption>Order by</fieldcaption><fielddescription>{$documentation.property.uniselectororderby$}</fielddescription></properties><settings><controlname>OrderBy</controlname></settings></field><category name="DropDownSettings"><properties><caption>Drop down settings</caption><visible>True</visible></properties></category><field allowempty="true" column="AllowEmpty" columntype="boolean" displayinsimplemode="true" guid="5d720369-c65e-496a-8387-dde801aad0d6" publicfield="false" visible="true"><properties><fieldcaption>Allow none</fieldcaption><fielddescription>{$documentation.property.uniselectorallowempty$}</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="AllowDefault" columntype="boolean" displayinsimplemode="true" guid="8135a068-6a0f-4899-8019-c45a655e7b83" publicfield="false" visible="true"><properties><fieldcaption>Allow default</fieldcaption><fielddescription>{$documentation.property.uniselectorallowdefault$}</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="AllowAll" columntype="boolean" displayinsimplemode="true" guid="d1586193-3c17-4f8c-9ab7-d4d481dd7f5f" publicfield="false" visible="true"><properties><fieldcaption>Allow all</fieldcaption><fielddescription>{$documentation.property.uniselectorallowall$}</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="DialogSettings"><properties><caption>Dialog settings</caption><visible>True</visible></properties></category><field allowempty="true" column="SelectorGridName" columnsize="100" columntype="text" displayinsimplemode="true" guid="6e1db597-9cf8-4b84-b2c2-c1ce02a7e299" publicfield="false" visible="true"><properties><fieldcaption>Selector grid name</fieldcaption><fielddescription>Sets the path to the UniGrid XML definition file used by the list of selected items in Multiple selection mode.</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="DialogGridName" columnsize="400" columntype="text" displayinsimplemode="true" guid="edfc6e6f-0e7b-402d-8b87-45af2019e2e8" publicfield="false" visible="true"><properties><fieldcaption>Dialog grid name</fieldcaption><fielddescription>{$documentation.property.DialogGridName$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="NewItemPageUrl" columnsize="400" columntype="text" displayinsimplemode="true" guid="72407864-db1c-46b6-b699-773003827d60" publicfield="false" visible="true"><properties><fieldcaption>New item page URL</fieldcaption><fielddescription>{$documentation.property.NewItemPageUrl$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="EditItemPageUrl" columnsize="400" columntype="text" displayinsimplemode="true" guid="a37dbdeb-a0d9-4598-880a-fbc5e56cdfc0" publicfield="false" visible="true"><properties><fieldcaption>Edit item page URL</fieldcaption><fielddescription>{$documentation.property.editpageurl$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="SelectItemPageUrl" columnsize="400" columntype="text" displayinsimplemode="true" guid="1cb77352-41e4-42e9-8bfd-e154e96b5a5a" publicfield="false" visible="true"><properties><fieldcaption>Select item page URL</fieldcaption><fielddescription>{$documentation.property.selectitempageurl$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="VisibleCondition" columnsize="1000" columntype="text" displayinsimplemode="true" guid="8db8ba88-8dfd-47ec-9cf9-a5f0ede58d28" publicfield="false" visible="true"><properties><fieldcaption>Visible condition</fieldcaption><fielddescription>{$documentation.property.visiblecondition$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textareacontrol</controlname><FilterMode>False</FilterMode><IsTextArea>True</IsTextArea><Wrap>True</Wrap></settings></field><field allowempty="true" column="SelectorExtender" columnsize="200" columntype="text" displayinsimplemode="true" guid="9603f872-c799-4d53-a360-7677f2fae0fe" publicfield="false" visible="true"><properties><fieldcaption>Selector Extender</fieldcaption><fielddescription>{$documentation.property.uniselectorextender$}</fielddescription></properties><settings><ClassNameColumnName>SelectorExtenderClassName</ClassNameColumnName><controlname>assemblyclassselector</controlname><ShowClasses>True</ShowClasses><ShowEnumerations>False</ShowEnumerations><ShowInterfaces>False</ShowInterfaces></settings></field><field allowempty="true" column="SelectorExtenderClassName" columnsize="100" columntype="text" displayinsimplemode="true" guid="2630dbd6-07c8-4aaf-8132-faa97d0621fa" publicfield="false"><settings><controlname>textboxcontrol</controlname></settings></field><category name="HeaderActions"><properties><caption>Header actions</caption><visible>False</visible></properties></category><field allowempty="true" column="NewElement" columnsize="400" columntype="text" displayinsimplemode="true" guid="b397c1de-a932-489b-a8cb-fb38fc4cf99a" publicfield="false"><properties><fieldcaption>New element</fieldcaption><fielddescription>{$documentation.property.newelement$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><category name="Listing"><properties><visible>True</visible></properties></category><field allowempty="true" column="GridName" columnsize="200" columntype="text" displayinsimplemode="true" guid="d207fc9c-ac8e-4dff-8b4f-5a27024d1100" publicfield="false" visible="true"><properties><fieldcaption>Grid definition path</fieldcaption><fielddescription>{$documentation.property.gridname$}</fielddescription></properties><settings><AllowManage>True</AllowManage><controlname>filesystemselector</controlname><DefaultPath>App_Data/CMSModules</DefaultPath><NewTextFileExtension>xml</NewTextFileExtension><ShowFolders>False</ShowFolders></settings></field><field allowempty="true" column="WhereCondition" columnsize="600" columntype="text" displayinsimplemode="true" guid="4add8dfd-200a-47b8-8f05-289a9f37528c" publicfield="false" visible="true"><properties><fieldcaption>Where condition</fieldcaption><fielddescription>{$documentation.webpartproperties.where$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoSize>False</AutoSize><controlname>macroeditor</controlname><EditorMode>1</EditorMode><EnablePositionMember>False</EnablePositionMember><EnableSections>False</EnableSections><EnableViewState>False</EnableViewState><FilterMode>False</FilterMode><Height>100</Height><IsTextArea>True</IsTextArea><Language>6</Language><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><ShowMacroSelector>False</ShowMacroSelector><SingleLineMode>False</SingleLineMode><SingleMacroMode>False</SingleMacroMode><SupportPasteImages>False</SupportPasteImages><Width>100</Width><Wrap>True</Wrap></settings></field><field allowempty="true" column="OrderBy" columnsize="200" columntype="text" displayinsimplemode="true" guid="72448c91-8bad-4533-ac1d-404471320e53" publicfield="false" visible="true"><properties><fieldcaption>Order by</fieldcaption><fielddescription>{$documentation.webpartproperties.orderby$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="EditActionURL" columnsize="400" columntype="text" displayinsimplemode="true" guid="1563e46e-3840-4665-b729-e7124f131b63" publicfield="false" visible="true"><properties><fieldcaption>Edit action URL</fieldcaption><fielddescription>{$documentation.property.editactionurl$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="AfterDeleteScript" columnsize="400" columntype="text" displayinsimplemode="true" guid="2b6fa7c5-e84a-4883-94f4-02c546fef347" publicfield="false" visible="true"><properties><fieldcaption>After delete script</fieldcaption><fielddescription>{$documentation.property.afterdeletescript$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoSize>False</AutoSize><controlname>macroeditor</controlname><EditorMode>0</EditorMode><EnablePositionMember>False</EnablePositionMember><EnableSections>False</EnableSections><EnableViewState>False</EnableViewState><FilterMode>False</FilterMode><Height>100</Height><Language>3</Language><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><ShowMacroSelector>False</ShowMacroSelector><SingleLineMode>False</SingleLineMode><SingleMacroMode>False</SingleMacroMode><SupportPasteImages>False</SupportPasteImages><Trim>False</Trim><Width>100</Width></settings></field><field allowempty="true" column="Text" columnsize="400" columntype="text" guid="005b3063-9594-4a78-8d75-7587ca19f5b5" publicfield="false" visible="true"><properties><fieldcaption>Text</fieldcaption><fielddescription>{$test.TextDisplayedAboveListing$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoSize>False</AutoSize><controlname>macroeditor</controlname><EditorMode>0</EditorMode><EnablePositionMember>False</EnablePositionMember><EnableSections>False</EnableSections><EnableViewState>False</EnableViewState><FilterMode>False</FilterMode><Height>100</Height><Language>0</Language><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><ShowMacroSelector>False</ShowMacroSelector><SingleLineMode>False</SingleLineMode><SingleMacroMode>False</SingleMacroMode><SupportPasteImages>False</SupportPasteImages><Trim>False</Trim><Width>100</Width></settings></field><field allowempty="true" column="ZeroRowsText" columnsize="200" columntype="text" displayinsimplemode="true" guid="54d9c040-d13e-4af7-bca4-441b04d94474" publicfield="false" visible="true"><properties><fieldcaption>Zero rows text</fieldcaption><fielddescription>{$documentation.property.zerorowstext$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="GridExtender" columnsize="200" columntype="text" displayinsimplemode="true" guid="5437442f-ce1b-4295-8e75-9de9afd3bc78" publicfield="false" visible="true"><properties><fieldcaption>Grid extender</fieldcaption><fielddescription>{$documentation.property.gridextender$}</fielddescription></properties><settings><ClassNameColumnName>GridExtenderClassName</ClassNameColumnName><controlname>assemblyclassselector</controlname><ShowClasses>True</ShowClasses><ShowEnumerations>False</ShowEnumerations><ShowInterfaces>False</ShowInterfaces></settings></field><field allowempty="true" column="GridExtenderClassName" columnsize="100" columntype="text" displayinsimplemode="true" guid="5ef2d69d-23ac-4e02-9bc3-7e94836ea36c" publicfield="false"><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><category name="SettingKeys"><properties><caption>{$webpart.documentation.DisabledModuleInfo$}</caption><collapsedbydefault>true</collapsedbydefault><collapsible>true</collapsible><visible>True</visible></properties></category><field allowempty="true" column="SettingKeys" columnsize="200" columntype="text" displayinsimplemode="true" guid="7af87d6b-d6a1-4290-838b-4ee66850b066" publicfield="false" visible="true"><properties><fieldcaption>Checked setting keys</fieldcaption><fielddescription>{$webpart.settingkeys.description$}</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field></form>'
    WHERE [PageTemplateGUID] = '46008814-f594-420e-b391-1c6e5abb26bd'


END

END


GO

-- HF12-58 - FormFieldSelector form control configuration change
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 11
BEGIN

DECLARE @userControlResourceID int;
SET @userControlResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceGUID] = '385e528a-e013-4a84-bad9-d5956408741a')
IF @userControlResourceID IS NOT NULL BEGIN

UPDATE [CMS_FormUserControl] SET 
        [UserControlParameters] = '<form version="2"><field column="FieldsDataType" columnsize="200" columntype="text" guid="afc0323b-5fbc-429a-9afb-5547bad90c30" publicfield="false" resolvedefaultvalue="False" visible="true"><properties><explanationtext>{$formfieldselector.fieldsdatatype.explanation$}</explanationtext><fieldcaption>{$formfieldselector.fieldsdatatype.caption$}</fieldcaption><fielddescription>{$formfieldselector.fieldsdatatype.description$}</fielddescription></properties><settings><controlname>DropDownListControl</controlname><DisplayActualValueAsItem>False</DisplayActualValueAsItem><EditText>False</EditText><Options>all;All
text;Text
longtext;LongText
integer;Integer
longinteger;LongInteger
double;Double
datetime;DateTime
boolean;Boolean
file;File
guid;Guid
binary;Binary
decimal;Decimal
timespan;Timespan
date;Date</Options><SortItems>False</SortItems></settings></field></form>'
    WHERE [UserControlGUID] = 'd4bc018e-e9b9-4784-a211-a91359ea6cd5' AND [UserControlParentID] IS NULL


END

END


GO

-- HF12-64 Update Seznam's search engine domain rule
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 13
BEGIN

UPDATE [CMS_SearchEngine] SET
        [SearchEngineDomainRule] = 'search.seznam.cz'
    WHERE [SearchEngineGUID] = '0178936b-99ae-4257-b87e-7059421e35e7' AND [SearchEngineDomainRule] = 'seznam.cz'


END

GO


-- HF12-88 Set correct macro resolver for email template fields
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 17
BEGIN

DECLARE @classID int;
SET @classID = (SELECT TOP 1 [ClassID] FROM [CMS_Class] WHERE [ClassName] = 'cms.emailtemplate');

DECLARE @classFormDefinition nvarchar(max);
SELECT @classFormDefinition = [ClassFormDefinition] FROM [CMS_Class] WHERE [ClassID] = @classID;

SET @classFormDefinition = REPLACE(@classFormDefinition, N'<ResolverName ismacro="true">{%EmailTemplateType%}</ResolverName>', N'<ResolverName ismacro="true">{%EmailTemplateType%}resolver</ResolverName>')

UPDATE [CMS_Class] SET [ClassFormDefinition] = @classFormDefinition WHERE [ClassID] = @classID;

END

GO

-- HF12-113 Set correct macro resolver for plain text
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 25
BEGIN

DECLARE @classID int;
SET @classID = (SELECT TOP 1 [ClassID] FROM [CMS_Class] WHERE [ClassName] = 'newsletter.issue');

DECLARE @alternativeFormDefinition nvarchar(max);
SELECT @alternativeFormDefinition = [FormDefinition] FROM [CMS_AlternativeForm] WHERE [FormClassID] = @classID AND [FormGUID] = '5adc8936-7ff2-4585-89f3-cd22cb86dbcf';

SET @alternativeFormDefinition = REPLACE(@alternativeFormDefinition, N'<ResolverName>Newsletter</ResolverName>', N'<ResolverName>NewsletterResolver</ResolverName>')

UPDATE [CMS_AlternativeForm] SET [FormDefinition] = @alternativeFormDefinition WHERE [FormClassID] = @classID AND [FormGUID] = '5adc8936-7ff2-4585-89f3-cd22cb86dbcf';

END

GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '28' WHERE KeyName = N'CMSHotfixVersion'
GO
